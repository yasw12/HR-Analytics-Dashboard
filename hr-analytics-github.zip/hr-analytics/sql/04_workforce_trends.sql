-- ============================================
-- 04_workforce_trends.sql
-- HR Analytics - Workforce Trend Reporting
-- Author: Yaswanth Kumar Mandla
-- ============================================

USE hr_analytics;

-- ── 1. Monthly Attrition Trend ────────────────────────────
SELECT
    DATE_FORMAT(attrition_date, '%Y-%m') AS month,
    COUNT(*) AS employees_left
FROM employees
WHERE attrition = 'Yes'
  AND attrition_date IS NOT NULL
GROUP BY month
ORDER BY month;

-- ── 2. Department-wise Average Tenure ────────────────────
SELECT
    department,
    ROUND(AVG(tenure_years), 1) AS avg_tenure_years,
    MIN(tenure_years)            AS min_tenure,
    MAX(tenure_years)            AS max_tenure
FROM employees
GROUP BY department
ORDER BY avg_tenure_years ASC;

-- ── 3. Average Salary by Department & Role ───────────────
SELECT
    department,
    job_role,
    ROUND(AVG(monthly_income), 0) AS avg_monthly_income,
    COUNT(*) AS headcount
FROM employees
GROUP BY department, job_role
ORDER BY department, avg_monthly_income DESC;

-- ── 4. Performance Rating Distribution ───────────────────
SELECT
    performance_rating,
    COUNT(*) AS headcount,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM employees), 2) AS pct
FROM employees
GROUP BY performance_rating
ORDER BY performance_rating;

-- ── 5. Gender & Diversity Breakdown ──────────────────────
SELECT
    department,
    gender,
    COUNT(*) AS headcount,
    ROUND(AVG(monthly_income), 0) AS avg_income
FROM employees
GROUP BY department, gender
ORDER BY department, gender;

-- ── 6. Headcount by Salary Band & Department (Heatmap) ──
SELECT
    department,
    SUM(CASE WHEN salary_band = 'Low'  THEN 1 ELSE 0 END) AS low_salary,
    SUM(CASE WHEN salary_band = 'Mid'  THEN 1 ELSE 0 END) AS mid_salary,
    SUM(CASE WHEN salary_band = 'High' THEN 1 ELSE 0 END) AS high_salary
FROM employees
GROUP BY department
ORDER BY department;

-- ── 7. Work-Life Balance vs Performance ──────────────────
SELECT
    work_life_balance,
    ROUND(AVG(performance_rating), 2) AS avg_performance,
    ROUND(AVG(job_satisfaction), 2)   AS avg_satisfaction,
    COUNT(*) AS headcount
FROM employees
GROUP BY work_life_balance
ORDER BY work_life_balance;

-- ── 8. Monthly HR Summary Report ─────────────────────────
SELECT
    COUNT(*) AS total_headcount,
    ROUND(AVG(tenure_years), 1) AS avg_tenure,
    ROUND(AVG(monthly_income), 0) AS avg_salary,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS total_attrition,
    ROUND(
        SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
    ) AS attrition_rate_pct,
    ROUND(AVG(performance_rating), 2) AS avg_performance_rating,
    ROUND(AVG(job_satisfaction), 2)   AS avg_job_satisfaction
FROM employees;
