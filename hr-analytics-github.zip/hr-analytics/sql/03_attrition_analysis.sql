-- ============================================
-- 03_attrition_analysis.sql
-- HR Analytics - Attrition KPI Queries
-- Author: Yaswanth Kumar Mandla
-- ============================================

USE hr_analytics;

-- ── 1. Overall Attrition Rate ─────────────────────────────
SELECT
    COUNT(*) AS total_employees,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS total_attrited,
    ROUND(
        SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
    ) AS attrition_rate_pct
FROM employees;

-- ── 2. Attrition by Department ────────────────────────────
SELECT
    department,
    COUNT(*) AS headcount,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS attrited,
    ROUND(
        SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
    ) AS attrition_rate_pct
FROM employees
GROUP BY department
ORDER BY attrition_rate_pct DESC;

-- ── 3. Attrition by Salary Band ───────────────────────────
SELECT
    salary_band,
    COUNT(*) AS headcount,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS attrited,
    ROUND(
        SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
    ) AS attrition_rate_pct
FROM employees
GROUP BY salary_band
ORDER BY FIELD(salary_band, 'Low', 'Mid', 'High');

-- ── 4. High-Risk Segments (Tenure 1–3 yrs + Low Salary) ──
SELECT
    department,
    job_role,
    salary_band,
    tenure_years,
    COUNT(*) AS at_risk_employees
FROM employees
WHERE attrition = 'Yes'
  AND tenure_years BETWEEN 1 AND 3
  AND salary_band = 'Low'
GROUP BY department, job_role, salary_band, tenure_years
ORDER BY at_risk_employees DESC;

-- ── 5. Attrition by Age Group ─────────────────────────────
SELECT
    CASE
        WHEN age BETWEEN 18 AND 25 THEN '18–25'
        WHEN age BETWEEN 26 AND 35 THEN '26–35'
        WHEN age BETWEEN 36 AND 45 THEN '36–45'
        ELSE '46+'
    END AS age_group,
    COUNT(*) AS headcount,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS attrited,
    ROUND(
        SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
    ) AS attrition_rate_pct
FROM employees
GROUP BY age_group
ORDER BY age_group;

-- ── 6. Impact of Overtime on Attrition ───────────────────
SELECT
    overtime,
    COUNT(*) AS headcount,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS attrited,
    ROUND(
        SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
    ) AS attrition_rate_pct
FROM employees
GROUP BY overtime;

-- ── 7. Job Satisfaction vs Attrition ─────────────────────
SELECT
    job_satisfaction,
    COUNT(*) AS headcount,
    SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS attrited,
    ROUND(
        SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
    ) AS attrition_rate_pct
FROM employees
GROUP BY job_satisfaction
ORDER BY job_satisfaction;
