-- ============================================
-- 02_data_cleaning.sql
-- HR Analytics - Data Cleaning & Transformation
-- Author: Yaswanth Kumar Mandla
-- ============================================

USE hr_analytics;

-- ── 1. Check for NULL values ──────────────────────────────
SELECT
    SUM(CASE WHEN emp_name IS NULL THEN 1 ELSE 0 END)         AS null_name,
    SUM(CASE WHEN age IS NULL THEN 1 ELSE 0 END)               AS null_age,
    SUM(CASE WHEN department IS NULL THEN 1 ELSE 0 END)        AS null_dept,
    SUM(CASE WHEN monthly_income IS NULL THEN 1 ELSE 0 END)    AS null_income,
    SUM(CASE WHEN attrition IS NULL THEN 1 ELSE 0 END)         AS null_attrition
FROM employees;

-- ── 2. Remove duplicate records ───────────────────────────
DELETE e1 FROM employees e1
INNER JOIN employees e2
    ON e1.emp_name = e2.emp_name
    AND e1.date_of_joining = e2.date_of_joining
    AND e1.employee_id > e2.employee_id;

-- ── 3. Standardize text columns ───────────────────────────
UPDATE employees SET gender = TRIM(UPPER(SUBSTRING(gender, 1, 1)));
UPDATE employees SET attrition = TRIM(INITCAP(attrition));
UPDATE employees SET overtime  = TRIM(INITCAP(overtime));

-- ── 4. Assign salary bands based on monthly income ────────
UPDATE employees
SET salary_band = CASE
    WHEN monthly_income < 30000  THEN 'Low'
    WHEN monthly_income < 70000  THEN 'Mid'
    ELSE 'High'
END;

-- ── 5. Fill missing tenure using joining date ──────────────
UPDATE employees
SET tenure_years = TIMESTAMPDIFF(YEAR, date_of_joining, CURDATE())
WHERE tenure_years IS NULL AND date_of_joining IS NOT NULL;

-- ── 6. Cap outlier ages ────────────────────────────────────
UPDATE employees SET age = 18 WHERE age < 18;
UPDATE employees SET age = 60 WHERE age > 60;

-- ── 7. Verify cleaned data ────────────────────────────────
SELECT COUNT(*) AS total_records FROM employees;
SELECT department, COUNT(*) AS headcount FROM employees GROUP BY department ORDER BY headcount DESC;
