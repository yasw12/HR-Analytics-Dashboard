-- ============================================
-- 01_create_tables.sql
-- HR Analytics - Database Schema Setup
-- Author: Yaswanth Kumar Mandla
-- ============================================

CREATE DATABASE IF NOT EXISTS hr_analytics;
USE hr_analytics;

DROP TABLE IF EXISTS employees;

CREATE TABLE employees (
    employee_id         INT PRIMARY KEY AUTO_INCREMENT,
    emp_name            VARCHAR(100),
    age                 INT,
    gender              VARCHAR(10),
    department          VARCHAR(50),
    job_role            VARCHAR(50),
    education           VARCHAR(50),
    education_field     VARCHAR(50),
    marital_status      VARCHAR(20),
    date_of_joining     DATE,
    tenure_years        INT,
    monthly_income      DECIMAL(10, 2),
    salary_band         VARCHAR(20),   -- Low / Mid / High
    performance_rating  INT,           -- 1 to 4
    job_satisfaction    INT,           -- 1 to 4
    work_life_balance   INT,           -- 1 to 4
    overtime            VARCHAR(5),    -- Yes / No
    distance_from_home  INT,           -- in km
    num_companies_worked INT,
    attrition           VARCHAR(5),    -- Yes / No
    attrition_date      DATE,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
