# 🚀 GitHub Deployment Guide

## Step-by-Step Instructions

### 1. Install Git (if not installed)
Download from https://git-scm.com/downloads and install.

### 2. Create GitHub Repository
1. Go to https://github.com → Click **"New"**
2. Repository name: `hr-employee-attrition-analytics`
3. Set to **Public** (so recruiters can view it)
4. Do NOT initialize with README (we have one)
5. Click **"Create repository"**

### 3. Generate Sample Data
```bash
cd hr-analytics/data
python generate_hr_data.py
```

### 4. Initialize & Push to GitHub
```bash
# Navigate to project folder
cd hr-analytics

# Initialize git
git init

# Add all files
git add .

# First commit
git commit -m "Initial commit: HR Attrition & Workforce Analytics Dashboard"

# Connect to your GitHub repo (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/hr-employee-attrition-analytics.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### 5. Add Project to LinkedIn & Resume
- **Resume:** `HR Employee Attrition & Workforce Analytics Dashboard | SQL | Excel | Power BI`
- **LinkedIn:** Add under Projects section with GitHub link
- **GitHub Profile:** Pin this repository on your profile

---

## 📌 Tips for Recruiter Appeal
- Add a **screenshot** of your Power BI dashboard to the README
- Keep commits descriptive: `git commit -m "Add attrition KPI queries"`
- Add topics/tags on GitHub: `data-analysis`, `power-bi`, `sql`, `hr-analytics`
