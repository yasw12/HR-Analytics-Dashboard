"""
generate_hr_data.py
Generates a realistic HR employee dataset (10,000 records) for the
HR Attrition & Workforce Analytics project.

Usage:
    python generate_hr_data.py

Output:
    data/hr_raw_data.csv
    data/hr_cleaned_data.csv

Author: Yaswanth Kumar Mandla
"""

import csv
import random
import os
from datetime import date, timedelta

random.seed(42)

DEPARTMENTS = {
    "Sales":       {"roles": ["Sales Executive", "Sales Manager", "Area Manager"],       "attrition_weight": 0.28},
    "HR":          {"roles": ["HR Executive", "HR Manager", "Recruiter"],                "attrition_weight": 0.22},
    "Technology":  {"roles": ["Software Developer", "Data Analyst", "QA Engineer"],      "attrition_weight": 0.14},
    "Finance":     {"roles": ["Finance Analyst", "Accountant", "Audit Manager"],         "attrition_weight": 0.12},
    "Operations":  {"roles": ["Operations Analyst", "Logistics Manager", "Coordinator"], "attrition_weight": 0.16},
    "Marketing":   {"roles": ["Marketing Analyst", "Brand Manager", "SEO Specialist"],   "attrition_weight": 0.18},
}

EDUCATION      = ["Bachelor's", "Master's", "PhD", "Diploma", "High School"]
EDU_FIELDS     = ["Computer Science", "Business", "Engineering", "Finance", "Marketing", "Life Sciences"]
MARITAL_STATUS = ["Single", "Married", "Divorced"]
GENDERS        = ["Male", "Female"]

def random_date(start_year=2015, end_year=2023):
    start = date(start_year, 1, 1)
    end   = date(end_year, 12, 31)
    return start + timedelta(days=random.randint(0, (end - start).days))

def salary_for(dept, role, tenure):
    base = {
        "Sales": 28000, "HR": 30000, "Technology": 45000,
        "Finance": 38000, "Operations": 32000, "Marketing": 35000,
    }.get(dept, 30000)
    role_bump   = 10000 if "Manager" in role else (5000 if "Senior" in role else 0)
    tenure_bump = tenure * 1500
    noise       = random.randint(-3000, 3000)
    return max(15000, base + role_bump + tenure_bump + noise)

rows = []
for i in range(1, 10001):
    dept       = random.choice(list(DEPARTMENTS.keys()))
    dept_info  = DEPARTMENTS[dept]
    role       = random.choice(dept_info["roles"])
    gender     = random.choice(GENDERS)
    age        = random.randint(22, 58)
    doj        = random_date()
    tenure     = date.today().year - doj.year
    income     = salary_for(dept, role, tenure)
    salary_band = "Low" if income < 30000 else ("Mid" if income < 70000 else "High")
    performance = random.choices([1, 2, 3, 4], weights=[5, 20, 55, 20])[0]
    satisfaction = random.choices([1, 2, 3, 4], weights=[10, 20, 45, 25])[0]
    wlb         = random.choices([1, 2, 3, 4], weights=[8, 22, 50, 20])[0]
    overtime    = random.choices(["Yes", "No"], weights=[30, 70])[0]
    distance    = random.randint(1, 30)
    companies   = random.randint(1, 6)
    education   = random.choice(EDUCATION)
    edu_field   = random.choice(EDU_FIELDS)
    marital     = random.choice(MARITAL_STATUS)

    # Attrition logic — weighted by dept, salary, tenure, overtime
    att_prob = dept_info["attrition_weight"]
    if salary_band == "Low":   att_prob += 0.10
    if tenure <= 3:            att_prob += 0.08
    if overtime == "Yes":      att_prob += 0.06
    if satisfaction <= 2:      att_prob += 0.07
    attrition = "Yes" if random.random() < att_prob else "No"
    att_date  = str(random_date(2022, 2024)) if attrition == "Yes" else ""

    rows.append([
        i, f"EMP_{i:05d}", age, gender, dept, role, education, edu_field,
        marital, str(doj), tenure, round(income, 2), salary_band,
        performance, satisfaction, wlb, overtime, distance, companies,
        attrition, att_date
    ])

HEADERS = [
    "employee_id", "emp_name", "age", "gender", "department", "job_role",
    "education", "education_field", "marital_status", "date_of_joining",
    "tenure_years", "monthly_income", "salary_band", "performance_rating",
    "job_satisfaction", "work_life_balance", "overtime", "distance_from_home",
    "num_companies_worked", "attrition", "attrition_date"
]

os.makedirs("data", exist_ok=True)

with open("data/hr_raw_data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(HEADERS)
    writer.writerows(rows)

# Cleaned = same data (already clean from generation); in real project this
# would be the output after SQL/Excel cleaning steps.
with open("data/hr_cleaned_data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(HEADERS)
    writer.writerows(rows)

print(f"✅ Generated {len(rows)} employee records.")
print("   → data/hr_raw_data.csv")
print("   → data/hr_cleaned_data.csv")
