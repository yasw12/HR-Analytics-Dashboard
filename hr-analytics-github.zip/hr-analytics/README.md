# 👥 HR Employee Attrition & Workforce Analytics Dashboard

![Python](https://img.shields.io/badge/SQL-MySQL-blue) ![Excel](https://img.shields.io/badge/Excel-Advanced-green) ![PowerBI](https://img.shields.io/badge/PowerBI-Dashboard-yellow)

## 📌 Project Overview
An end-to-end HR analytics project analyzing **10,000+ employee records** to uncover attrition patterns, workforce trends, and retention risks. Built an interactive **Power BI dashboard** to support HR leadership in strategic decision-making.

---

## 🎯 Business Problem
HR teams struggle to identify **why employees leave** and **who is at risk**. This project answers:
- Which departments have the highest attrition rates?
- What salary bands and tenure groups are most at risk?
- What KPIs should HR track monthly for workforce health?

---

## 🛠️ Tools & Technologies
| Tool | Usage |
|------|-------|
| **SQL (MySQL)** | Data extraction, transformation, KPI queries |
| **Excel** | Data cleaning, Pivot Tables, VLOOKUP, dashboards |
| **Power BI** | Interactive dashboard & visual reporting |

---

## 📁 Project Structure
```
hr-analytics/
│
├── data/
│   ├── hr_raw_data.csv           # Raw employee dataset
│   └── hr_cleaned_data.csv       # Cleaned dataset
│
├── sql/
│   ├── 01_create_tables.sql      # Schema setup
│   ├── 02_data_cleaning.sql      # Cleaning queries
│   ├── 03_attrition_analysis.sql # Attrition KPI queries
│   └── 04_workforce_trends.sql   # Trend analysis queries
│
├── excel/
│   └── HR_Dashboard.xlsx         # Excel pivot dashboard
│
├── powerbi/
│   └── HR_Analytics.pbix         # Power BI dashboard file
│
├── reports/
│   └── HR_Insights_Report.pdf    # Final insights report
│
└── README.md
```

---

## 📊 Key Insights Uncovered
- 📉 **Attrition Rate: 16.2%** — highest in Sales (24%) and HR (22%) departments
- ⚠️ **High-Risk Segment:** Employees with **1–3 years tenure** + below-average salary
- 💰 Employees earning **< ₹30K/month** are **3x more likely** to leave
- 📅 Attrition peaks at **Q1 (Jan–Mar)** — correlated with appraisal cycles
- 🏆 Departments with structured mentorship show **40% lower attrition**

---

## 🗂️ Dashboard KPIs Tracked
- Total Headcount & Monthly Headcount Trend
- Overall & Department-wise Attrition Rate
- Average Tenure by Department
- Salary Band vs Attrition Heatmap
- Performance Score Distribution
- Age Group & Gender Attrition Breakdown

---

## ▶️ How to Run

### SQL
```bash
# Import schema and data
mysql -u root -p < sql/01_create_tables.sql
mysql -u root -p hr_analytics < sql/02_data_cleaning.sql
mysql -u root -p hr_analytics < sql/03_attrition_analysis.sql
```

### Excel
Open `excel/HR_Dashboard.xlsx` — all Pivot Tables auto-refresh from the cleaned CSV.

### Power BI
Open `powerbi/HR_Analytics.pbix` in Power BI Desktop. Update the data source path to your local `hr_cleaned_data.csv`.

---

## 👤 Author
**Yaswanth Kumar Mandla** — Fresher Data Analyst  
📧 yaswanthkumarmandla68@gmail.com  
🔗 [LinkedIn](https://linkedin.com/in/yaswanthkumarmandla)
